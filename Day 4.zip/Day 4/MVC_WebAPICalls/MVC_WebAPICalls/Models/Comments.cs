﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace MVC_WebAPICalls.Models
{
    public class Comments
    {
        public string PostId { get; set; }
        public string id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string body { get; set; }

        List<Comments> commentsData = new List<Comments>();

        public List<Comments> GetComments()
        {

            HttpClient client = new HttpClient();
            string url = "https://jsonplaceholder.typicode.com/comments";

            client.DefaultRequestHeaders.Accept.Clear(); //different browsers makes call in different formats
                                                         //eg. chrome in XML, iExplore in JSON, safari, opera, firefox in their own formats

            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

          var call =  client.GetAsync(url);
            List<Comments> data = new List<Comments>();
            var response = call.Result;
            if (response.IsSuccessStatusCode)
            {
                var read = response.Content.ReadAsAsync<List<Comments>>();
                read.Wait();
                data = read.Result;
            }

            return data;
        }
    }
}
