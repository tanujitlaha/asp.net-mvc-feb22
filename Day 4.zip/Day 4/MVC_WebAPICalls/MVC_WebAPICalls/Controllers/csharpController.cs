﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_WebAPICalls.Models;
namespace MVC_WebAPICalls.Controllers
{
    public class csharpController : Controller
    {

        Comments commentObj = new Comments();

        public IActionResult ComemntsData()
        {
            ViewBag.data = commentObj.GetComments();
            return View();
        }

        public IActionResult test()
        {

            ViewData["firstNumber"] = 20;
            ViewData["secondNumber"] = 30;

            ViewBag.firstNumber = 20;
            ViewBag.secondNumber = 30;




            return View();
        }
    }
}