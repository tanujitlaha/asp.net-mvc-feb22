create database products
use products

create table products
(
	pId int primary key,
	pName varchar(20),
	pCategoty varchar(20),
	pPrice int)

	insert into products values(1, 'Pepsi','Cold-Drink',20)
	insert into products values(2, 'Coke','Cold-Drink',20)
	insert into products values(3, 'Maggie','Cold-Drink',20)

	select * from products

