﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using employeeWebAPI.Models;

namespace employeeWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class employeeManagementController : ControllerBase
    {

        #region DI

        //EmployeeDetails empObj = new EmployeeDetails(); //this is not a good practice


        EmployeeDetails _empObj;

        public employeeManagementController(EmployeeDetails empObjRef)
        {
            _empObj = empObjRef;
        }
        #endregion
        #region Get Operations
        [Route("elist")]
        public IActionResult GetAllEmployee()
        {
            return Ok(_empObj.GetAllEmployees());
        }
        [Route("permenant")]
        public IActionResult GetAllPermenantEmployee()
        {
            return Ok(_empObj.GetPermenantEmployees());
        }
        [Route("contract")]
        public IActionResult GetAllContractEmployee()
        {
            return Ok(_empObj.GetContractEmployees());
        }
        [Route("emp/{id}")]
        public IActionResult GetbyId(int id)
        {
            return Ok(_empObj.GetById(id));
        }
        [Route("total")]
        public IActionResult GetTotal()
        {
            return Ok(_empObj.TotalEmployees());
        }
        #endregion

        [HttpPost]
        [Route("add")]
        public IActionResult AddEmployee(EmployeeDetails newEmp)
        {
            return Ok(_empObj.AddEmployee(newEmp));
        }

        [HttpDelete]
        [Route("delete/{eNo}")]
        public IActionResult DeleteEmployee(int eNo)
        {
            return StatusCode(StatusCodes.Status410Gone, _empObj.DeleteEmployee(eNo));
        }

        [HttpPut]
        [Route("update")]
        public IActionResult UpdateEmployee(EmployeeDetails changes)
        {
            return StatusCode(StatusCodes.Status200OK, _empObj.UpdateEmployee(changes));
        }




    }
}