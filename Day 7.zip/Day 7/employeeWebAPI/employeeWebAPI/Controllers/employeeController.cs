﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace employeeWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class employeeController : ControllerBase
    {

        [Route("greet")]
        public IActionResult Getgreetings()
        {
            //we return HttpStatus Code
            return Ok("Hello and Welcome to Web API World");
        }

        [Route("greeting")]

        public IActionResult GetGreetings(string guestName)
        {
            return Ok("Hello " + guestName);
        }

        [Route("add")]
        public IActionResult GetAddiction(int num1, int num2)
        {
            return Ok("Addition of Numbers are " + (num1 + num2));
        }

        [Route("friends")]
        public IActionResult GetFriends()
        {
            List<string> friendsList = new List<string>();
            friendsList.Add("Akshay");
            friendsList.Add("Rahul");
            friendsList.Add("Karan");
            friendsList.Add("Priya");
            friendsList.Add("Riya");
            friendsList.Add("Sameer");
            friendsList.Add("Ramesh");
            friendsList.Add("Mohan");

            return Ok(friendsList);
        }

        [Route("employee")]
        public IActionResult GetEmployee()
        {
            //this is called as dynamic obj
            var empDetails = new 
            {
                empNo = 101, empName = "Rahul", empDesignation = "Sales", empSalary = 5000, empCity = "Pune"
            };

            return Ok(empDetails);
        }



    }
}