﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace employeeWebAPI.Models
{
    public class EmployeeDetails
    {
        #region Properties
        public int empNo { get; set; }
        public string empName { get; set; }
        public string empDesignation { get; set; }
        public double empSalary { get; set; }
        public bool empIsPermenant { get; set; }

        #endregion

        #region Get

        static List<EmployeeDetails> eList = new List<EmployeeDetails>()
        {
            new EmployeeDetails(){ empNo=101, empName="Rohan", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
            new EmployeeDetails(){ empNo=102, empName="Karan", empDesignation="HR", empIsPermenant=true, empSalary=15000},
            new EmployeeDetails(){ empNo=103, empName="Mohan", empDesignation="Sales", empIsPermenant=false, empSalary=25000},
            new EmployeeDetails(){ empNo=104, empName="Soham", empDesignation="Accounts", empIsPermenant=true, empSalary=35000},
            new EmployeeDetails(){ empNo=105, empName="Rakesh", empDesignation="Sales", empIsPermenant=false, empSalary=500},
            new EmployeeDetails(){ empNo=106, empName="Suresh", empDesignation="Sales", empIsPermenant=true, empSalary=200}
        };

        public List<EmployeeDetails> GetAllEmployees()
        {
            return eList;
        }

        public List<EmployeeDetails> GetPermenantEmployees()
        {
            var permenantEmp = (from e in eList
                                where e.empIsPermenant == true
                                select e).ToList();
            return permenantEmp;
        }

        public List<EmployeeDetails> GetContractEmployees()
        {
            var contractEmp = (from e in eList
                                where e.empIsPermenant == false
                                select e).ToList();
            return contractEmp;
        }

        public EmployeeDetails GetById(int empId)
        {
            var emp = eList.Find(e => e.empNo == empId);
            return emp;
        }

        public int TotalEmployees()
        {
            return eList.Count;
        }

        #endregion

        #region CRUD
        public string AddEmployee(EmployeeDetails newEmp)
        {
            eList.Add(newEmp);
            return "Employee Added Successfully";
        }

        public string DeleteEmployee(int id)
        {
            var emp = eList.Find(e => e.empNo == id);
            eList.Remove(emp);
            return "Employee Deleted";
        }

        public string UpdateEmployee(EmployeeDetails changes)
        {
            var emp = eList.Find(e => e.empNo == changes.empNo);
            emp.empName = changes.empName;
            emp.empDesignation = changes.empDesignation;
            emp.empSalary = changes.empSalary;

            return "Update Successful";
        }
        #endregion
    }
}






