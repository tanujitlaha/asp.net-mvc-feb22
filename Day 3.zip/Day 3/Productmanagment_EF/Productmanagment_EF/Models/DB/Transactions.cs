﻿using System;
using System.Collections.Generic;

namespace Productmanagment_EF.Models.DB
{
    public partial class Transactions
    {
        public int TId { get; set; }
        public int? TCustomer { get; set; }
        public int? TOrderValue { get; set; }
        public int? TProduct { get; set; }
        public DateTime? TDate { get; set; }

        public Customers TCustomerNavigation { get; set; }
        public ProductDetails TProductNavigation { get; set; }
    }
}
