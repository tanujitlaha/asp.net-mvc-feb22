﻿using System;
using System.Collections.Generic;

namespace Productmanagment_EF.Models.DB
{
    public partial class Customers
    {
        public Customers()
        {
            Transactions = new HashSet<Transactions>();
        }

        public int CId { get; set; }
        public string CName { get; set; }
        public string CLocation { get; set; }
        public int? CWalletBalance { get; set; }
        public string CEmail { get; set; }
        public long? CMobile { get; set; }
        public string CType { get; set; }

        public ICollection<Transactions> Transactions { get; set; }
    }
}
