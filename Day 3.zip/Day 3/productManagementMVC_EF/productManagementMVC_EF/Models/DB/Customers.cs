﻿using System;
using System.Collections.Generic;

namespace productManagementMVC_EF.Models.DB
{
    public partial class Customers
    {
        public int CId { get; set; }
        public string CName { get; set; }
        public string CLocation { get; set; }
        public int? CWalletBalance { get; set; }
        public string CEmail { get; set; }
    }
}
