﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repository_patternDemo.Models;
namespace repository_patternDemo.Repositories
{
    public interface IProductRepository
    {
        List<productModel> ProductList();
        productModel GetProductbyId(int id);

        string AddProduct(productModel newProduct);
        string Deleteproduct(int id);

        string EditProduct(productModel changes);
    }
}
