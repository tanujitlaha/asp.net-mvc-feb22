﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repository_patternDemo.Models;

namespace repository_patternDemo.Repositories.Collections
{
    public class ProductCollection : IProductRepository
    {
        static List<productModel> pList = new List<productModel>()
        {
            new productModel(){ pId=101, pName="Pepsi", pCategory="Cold-Drink", pIsInStock=true, pPrice=50},
            new productModel(){ pId=102, pName="Maggie", pCategory="Fast-Food", pIsInStock=true, pPrice=50},
            new productModel(){ pId=103, pName="Pasta", pCategory="Fast-Food", pIsInStock=true, pPrice=50},
            new productModel(){ pId=104, pName="IPhone", pCategory="Electronics", pIsInStock=true, pPrice=50},
        };


        public string AddProduct(productModel newProduct)
        {
            pList.Add(newProduct);
            return "Product Added To Collection";
        }

        public string Deleteproduct(int id)
        {
            pList.Remove(pList.Find(pr => pr.pId == id));
            return "Product Deleted From Collection";
        }

        public string EditProduct(productModel changes)
        {
            var product = pList.Find(pr => pr.pId == changes.pId);
            product.pName = changes.pName;
            product.pCategory = changes.pCategory;
            product.pPrice = changes.pPrice;

            return "Product Updated in Collection";
        }

        public productModel GetProductbyId(int id)
        {
            var product = pList.Find(pr => pr.pId == id);
            return product;
        }

        public List<productModel> ProductList()
        {
            return pList;
        }
    }
}
