﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace repository_patternDemo.Repositories.SQLServer
{
    public partial class productsContext : DbContext
    {
        public productsContext()
        {
        }

        public productsContext(DbContextOptions<productsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Products> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=DESKTOP-NUK26IL\\MUMBAISERVER;database=products;integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Products>(entity =>
            {
                entity.HasKey(e => e.PId);

                entity.ToTable("products");

                entity.Property(e => e.PId)
                    .HasColumnName("pId")
                    .ValueGeneratedNever();

                entity.Property(e => e.PCategoty)
                    .HasColumnName("pCategoty")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PIsInStock).HasColumnName("pIsInStock");

                entity.Property(e => e.PName)
                    .HasColumnName("pName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PPrice).HasColumnName("pPrice");
            });
        }
    }
}
