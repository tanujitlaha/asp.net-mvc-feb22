﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repository_patternDemo.Models;
using repository_patternDemo.Repositories.SQLServer;

namespace repository_patternDemo.Repositories.SQL_Server
{
    public class ProductSQLServer : IProductRepository
    {
        productsContext _db; //register this guy for DI

        public ProductSQLServer(productsContext _productDBObjRef)
        {
            _db = _productDBObjRef;
        }

        public string AddProduct(productModel newProduct)
        {
            SQLServer.Products newP = new Products(); //instead u can use DI
            newP.PId = newProduct.pId;
            newP.PName = newProduct.pName;
            newP.PCategoty = newProduct.pCategory;
            newP.PPrice = Convert.ToInt32(newProduct.pPrice);
            newP.PIsInStock = newProduct.pIsInStock;


            _db.Products.Add(newP);
            _db.SaveChanges();
            return "Product Added to Database";
        }

        public string Deleteproduct(int id)
        {
            var p = (from pr in _db.Products
                     where pr.PId == id
                     select pr).Single();

            _db.Products.Remove(p);
            _db.SaveChanges();
            return "Product Deleted From Database";
        }

        public string EditProduct(productModel changes)
        {
            var p = (from pr in _db.Products
                     where pr.PId == changes.pId
                     select pr).Single();

            p.PName = changes.pName;
            p.PCategoty = changes.pCategory;
            p.PPrice = Convert.ToInt32(changes.pPrice);
            p.PIsInStock = changes.pIsInStock;

            _db.SaveChanges();
            return "Product updated in Database";
           
        }

        public productModel GetProductbyId(int id)
        {
            var p = (from pr in _db.Products
                     where pr.PId == id
                     select pr).Single();


            productModel model = new productModel(); //use DI instead
            model.pName = p.PName;
            model.pId = p.PId;
            model.pCategory = p.PCategoty;
            model.pIsInStock =(bool) p.PIsInStock;
            model.pPrice = Convert.ToInt32(p.PPrice);
            return model;


        }

        public List<productModel> ProductList()
        {
            var p = (from pr in _db.Products
                    select pr).ToList();

            List<productModel> pList = new List<productModel>();

            foreach (var item in p)
            {
                pList.Add(new productModel()
                {
                    pId = item.PId,
                    pName = item.PName,
                    pCategory = item.PCategoty,
                    pPrice = Convert.ToInt32(item.PPrice),
                    pIsInStock = (bool)item.PIsInStock

                });

              
            }
            return pList;
        }
    }
}
