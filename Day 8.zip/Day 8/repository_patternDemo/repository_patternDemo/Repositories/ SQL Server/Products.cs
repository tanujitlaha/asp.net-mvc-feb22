﻿using System;
using System.Collections.Generic;

namespace repository_patternDemo.Repositories.SQLServer
{
    public partial class Products
    {
        public int PId { get; set; }
        public string PName { get; set; }
        public string PCategoty { get; set; }
        public int? PPrice { get; set; }
        public bool? PIsInStock { get; set; }
    }
}
