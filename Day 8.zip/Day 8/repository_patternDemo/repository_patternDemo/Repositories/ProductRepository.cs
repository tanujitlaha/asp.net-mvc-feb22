﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repository_patternDemo.Models;

namespace repository_patternDemo.Repositories
{
    public class ProductRepository : IProductRepository
    {

        IProductRepository _product; //do not create any instance, let runtime do that
        public string AddProduct(productModel newProduct)
        {
            return _product.AddProduct(newProduct);
        }

        public string Deleteproduct(int id)
        {
            return _product.Deleteproduct(id);
        }

        public string EditProduct(productModel changes)
        {
            return _product.EditProduct(changes);
        }

        public productModel GetProductbyId(int id)
        {
            return _product.GetProductbyId(id);
        }

        public List<productModel> ProductList()
        {
            return _product.ProductList();
        }
    }
}
