﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using repository_patternDemo.Models;
using repository_patternDemo.Repositories;
namespace repository_patternDemo.Controllers
{
    public class ProductController : Controller
    {

        IProductRepository _repo;

        public ProductController(IProductRepository _repoObj)
        {
            _repo = _repoObj;
        }

        public IActionResult ProductList()
        {
            return View(_repo.ProductList());
        }


        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddProduct(productModel newObj)
        {
            _repo.AddProduct(newObj);
           return RedirectToAction("ProductList");
        }




        public IActionResult Index()
        {
            return View();
        }
    }
}