﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace repository_patternDemo.Models
{
    public class productModel
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public string pCategory { get; set; }
        public double pPrice { get; set; }
        public bool pIsInStock { get; set; }
    }
}
