﻿using System;
using Identity_Demo2.Areas.Identity.Data;
using Identity_Demo2.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(Identity_Demo2.Areas.Identity.IdentityHostingStartup))]
namespace Identity_Demo2.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<Identity_Demo2Context>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("Identity_Demo2ContextConnection")));

                services.AddDefaultIdentity<Identity_Demo2User>()
                    .AddEntityFrameworkStores<Identity_Demo2Context>();
            });
        }
    }
}