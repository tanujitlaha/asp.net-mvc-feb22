﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Identity_Demo2.Controllers
{
    [Authorize]
    public class BankAccountController : Controller
    {
        public IActionResult AccountsDetails()
        {
            return View();
        }

        public IActionResult TransferMoney()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult OpenNewBankAccount()
        {
            return View();
        }

    }
}