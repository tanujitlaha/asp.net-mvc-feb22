﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace employeeManagementMVC.Controllers
{
    public class GreetingsController : Controller
    {
        [HttpGet]
        public IActionResult Greetings()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Greetings(string guestName)
        {
            ViewBag.greetMessage = "Hello " + guestName + " This is a good day";
            return View();
        }

        public IActionResult CalculateNumbers()
        {
            ViewBag.hasValues = false;
            ViewBag.errMessage = "";
            return View();
        }

        [HttpPost]
        public IActionResult CalculateNumbers(int num1, int num2)
        {
            if (num1 == 0 || num2 == 0)
            {
                ViewBag.errMessage = "Enter Values Greater than Zero Only";
                ViewBag.hasValues = false;
            }
            else if (num1 < num2)
            {
                ViewBag.errMessage = "This will result in negative values, we do not process the same";
                ViewBag.hasValues = false;
            }
            else
            {
                ViewBag.addition = num1 + num2;
                ViewBag.subtraction = num1 - num2;
                ViewBag.division = num1 / num2;
                ViewBag.multiplication = num1 * num2;
                ViewBag.hasValues = true;
            }
            return View();
        }
    }
}