﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using employeeManagementMVC.Models;
namespace employeeManagementMVC.Controllers
{
    public class EmployeeCRUDController : Controller
    {
        EmployeeModel empObj = new EmployeeModel(); //this will get converted to dependency injection

        public IActionResult EmployeeList()
        {
            ViewBag.empDetails = empObj.Employeelist();
            return View();
        }

        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddEmployee(EmployeeModel newEmp)
        {
          ViewBag.message =   empObj.AddEmployee(newEmp);
            return RedirectToAction("EmployeeList");
        }
    }
}