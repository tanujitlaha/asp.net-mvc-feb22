﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using employeeManagementMVC.Models;
namespace employeeManagementMVC.Controllers
{
    public class EmployeeController : Controller
    {
      public IActionResult Employeelist()
        {
            ViewBag.totalEmp = 5;
            ViewBag.teamName = "Development";
            ViewBag.clientName = "Some Bank";
            ViewBag.isBilled = false;

            List<string> eList = new List<string>() { "Amar", "Akshay", "Rahul", "Sumit", "Naresh" };
            ViewBag.emplist = eList;
            return View();
        }

        public IActionResult EmployeeDetails()
        {
            EmployeeModel empModelObj = new EmployeeModel();
            ViewBag.empDetails = empModelObj.Employeelist();
            return View();
        }

        public IActionResult EmployeeImages()
        {
            return View();
        }
        public IActionResult CurrentOpenings()
        {
            return View();
        }
        public IActionResult WorkCulture()
        {
            return View();
        }
    }
}