﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace employeeManagementMVC.Models
{
    public class EmployeeModel
    {
        #region Properties
        public int empNo { get; set; }
        public string empName { get; set; }
        public double empSalary { get; set; }
        public string empDesignation { get; set; }
        public bool empIsPermenant { get; set; }
        #endregion

        //values could have come from database as well
        static List<EmployeeModel> emplist = new List<EmployeeModel>()
        {
            new EmployeeModel(){ empNo=101, empName="Priya", empDesignation="HR", empIsPermenant=true, empSalary=25000},
            new EmployeeModel(){ empNo=102, empName="Riya", empDesignation="Sales", empIsPermenant=true, empSalary=25000},
            new EmployeeModel(){ empNo=103, empName="Ramesh", empDesignation="HR", empIsPermenant=false, empSalary=25000},
            new EmployeeModel(){ empNo=104, empName="Suresh", empDesignation="Accounts", empIsPermenant=true, empSalary=25000},
            new EmployeeModel(){ empNo=105, empName="Karthik", empDesignation="HR", empIsPermenant=false, empSalary=25000},
        };

        public List<EmployeeModel> Employeelist()
        {
            return emplist;
        }

        public string AddEmployee(EmployeeModel newEmp)
        {
            emplist.Add(newEmp);
            return "Employee Added Successfully";
        }

        public string EditEmpoyee(EmployeeModel changes)
        {
            var emp = (from e in emplist where e.empNo == changes.empNo select e).Single();
            emp.empName = changes.empName;
            emp.empDesignation = changes.empDesignation;
            emp.empSalary = changes.empSalary;
            emp.empIsPermenant = changes.empIsPermenant;

            return "Employee Updated";
        }


        public string DeleteEmployee(int empNo)
        {
            var emp = (from e in emplist where e.empNo == empNo select e).Single();
            emplist.Remove(emp);
            return "Employee Removed successfully";
        }

    }
}
